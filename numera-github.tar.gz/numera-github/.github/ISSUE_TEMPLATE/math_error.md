---
name: Mathematical Error Report
about: Report a case where NUMERA produces an incorrect result
title: "[MATH ERROR] "
labels: bug, mathematical-error
---

## Expression
```
[Your expression here]
```

## Expected Result
[What the correct answer should be]

## NUMERA Result
[What NUMERA returned]

## How You Verified
[Calculator, Wolfram Alpha, manual computation, etc.]

---

NUMERA has a zero-tolerance policy for mathematical errors. Every incorrect result is a critical bug. Thank you for helping make AI math safer.
